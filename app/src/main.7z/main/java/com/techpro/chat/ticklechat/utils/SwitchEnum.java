package com.techpro.chat.ticklechat.utils;

public enum SwitchEnum {

    POSITIVE,
    NEGATIVE,
    NEUTRAL
}
