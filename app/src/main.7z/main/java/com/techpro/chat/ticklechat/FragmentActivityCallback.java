package com.techpro.chat.ticklechat;
/**
 * Created by vishalrandive on 06/04/16.
 */
public interface FragmentActivityCallback {
    void callBack();
}
