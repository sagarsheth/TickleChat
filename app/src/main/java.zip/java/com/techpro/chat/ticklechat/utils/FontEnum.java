package com.techpro.chat.ticklechat.utils;

public enum FontEnum {

    ROBOTO_REGULAR,
    ROBOTO_MEDIUM
}
