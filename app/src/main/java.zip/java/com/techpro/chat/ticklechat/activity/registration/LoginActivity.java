package com.techpro.chat.ticklechat.activity.registration;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.techpro.chat.ticklechat.R;

/**
 * Created by vishalrandive on 11/04/16.
 */
public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_new);
    }
}
