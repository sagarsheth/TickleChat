package com.techpro.chat.ticklechat.activity.registration;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.techpro.chat.ticklechat.R;

/**
 * Created by vishalrandive on 06/04/16.
 */
public class ForgetPassword extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);
    }
}
